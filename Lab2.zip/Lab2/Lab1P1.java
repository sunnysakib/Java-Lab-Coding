/*Write a Java program to print 'Hello' on screen and then 
print your name on a separate line.*/
package lab1p1;


public class Lab1P1 {

  
    public static void main(String[] args) {
        System.out.println("Hello");
        System.out.println("Donald Trump");
    }
    
}
